#ifndef _UIMG_H_
#define _UIMG_H_


#include <CImg.h>

using namespace cimg_library;


typedef unsigned char      T;
typedef CImg<T>            UImg;


#endif
